﻿using System.Linq;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Util;


namespace ColorfulCandles.src
{
    public class BlockChandelierColorful : Block
    {
        public int CandleCount
        {
            get
            {
                switch (LastCodePart())
                {
                    case "candle0":
                        return 0;
                    case "candle1":
                        return 1;
                    case "candle2":
                        return 2;
                    case "candle3":
                        return 3;
                    case "candle4":
                        return 4;
                    case "candle5":
                        return 5;
                    case "candle6":
                        return 6;
                    case "candle7":
                        return 7;
                    case "candle8":
                        return 8;
                }
                return -1;
            }
        }
        public override bool OnBlockInteractStart(IWorldAccessor world, IPlayer byPlayer, BlockSelection blockSel)
        {
            int candlecount = CandleCount;
            ItemStack itemstack = null;
            Block block = null;
            if (byPlayer.InventoryManager.ActiveHotbarSlot != null)
            {
                itemstack = byPlayer.InventoryManager.ActiveHotbarSlot.Itemstack;
            }
            if (itemstack != null)
            {
                var held = itemstack.Collectible.Code.Path;
                if ((held == "candle" || held.Contains("dyedcandle-") && CandleCount != 8))
                {
                    if (CandleCount == 0 && (held.Contains("dyedcandle-")))
                    {
                        var assetloc = ("colorfulcandles:chandelier" + held + "-candle1");
                        var newBlock = world.GetBlock(new AssetLocation(assetloc));
                        world.BlockAccessor.SetBlock(newBlock.BlockId, blockSel.Position);
                    }
                    else
                    {
                        block = world.GetBlock(CodeWithParts(GetNextCandleCount()));
                    }
                    if (byPlayer != null && byPlayer.WorldData.CurrentGameMode == EnumGameMode.Survival)
                    {
                        byPlayer.InventoryManager.ActiveHotbarSlot.TakeOut(1);
                    }
                    if (block != null)
                    {
                        world.BlockAccessor.ExchangeBlock(block.BlockId, blockSel.Position);
                    }
                    world.BlockAccessor.MarkBlockDirty(blockSel.Position);

                    return true;
                }
                {
                    if (CandleCount == 0 && (held.Contains("flamedcandle-")))
                    {
                        var assetloc = ("colorfulcandles:chandelier" + held + "-candle1");
                        var newBlock = world.GetBlock(new AssetLocation((assetloc)));
                        world.BlockAccessor.SetBlock(newBlock.BlockId, blockSel.Position);
                    }
                    else
                    {
                        block = world.GetBlock(CodeWithParts(GetNextCandleCount()));
                    }
                    if (byPlayer != null && byPlayer.WorldData.CurrentGameMode == EnumGameMode.Survival)
                    {
                        byPlayer.InventoryManager.ActiveHotbarSlot.TakeOut(1);
                    }
                    if (block != null)
                    {
                        world.BlockAccessor.ExchangeBlock(block.BlockId, blockSel.Position);
                    }
                    world.BlockAccessor.MarkBlockDirty(blockSel.Position);

                    return true;
                }
            }
            return false;
        }
        string GetNextCandleCount()
        {
            if (CandleCount != 8)
            {
                return "candle" + (CandleCount + 1).ToString();
            }
            else
                return "";
        }
        public override WorldInteraction[] GetPlacedBlockInteractionHelp(IWorldAccessor world, BlockSelection selection, IPlayer forPlayer)
        {
            if (CandleCount == 8) return null;

            return new WorldInteraction[]
            {
                new WorldInteraction()
                {
                    ActionLangCode = "game:blockhelp-chandelier-addcandle",
                    MouseButton = EnumMouseButton.Right,
                    Itemstacks = new ItemStack[] { new ItemStack(world.GetItem(new AssetLocation("game:candle"))) }
                }
            }.Append(base.GetPlacedBlockInteractionHelp(world, selection, forPlayer));
        }
    }
}
